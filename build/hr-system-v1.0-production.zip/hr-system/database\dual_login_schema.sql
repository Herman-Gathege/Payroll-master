-- ============================================================================
-- HR Management System Database Schema - Dual Login System
-- ============================================================================
-- Version: 2.0
-- Date: October 16, 2025
-- Description: Enhanced schema with separate employer and employee authentication
-- Kenyan Compliance: SHIF, NSSF, KRA, Employment Act 2007
-- ============================================================================

-- Drop existing database if exists (for clean installation)
-- DROP DATABASE IF EXISTS hr_management_system;
-- CREATE DATABASE hr_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE hr_management_system;

-- ============================================================================
-- SECTION 1: ORGANIZATION & EMPLOYER MANAGEMENT
-- ============================================================================

-- Organizations/Companies Table
CREATE TABLE organizations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_name VARCHAR(255) NOT NULL,
    organization_code VARCHAR(50) UNIQUE NOT NULL,
    business_registration_number VARCHAR(100) UNIQUE,
    kra_pin VARCHAR(20),
    nssf_employer_number VARCHAR(50),
    shif_employer_number VARCHAR(50),
    business_type VARCHAR(100),
    industry VARCHAR(100),
    phone_number VARCHAR(20),
    email VARCHAR(255),
    website VARCHAR(255),
    physical_address TEXT,
    postal_address VARCHAR(255),
    county VARCHAR(100),
    country VARCHAR(100) DEFAULT 'Kenya',
    logo_path VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_org_code (organization_code),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 2: AUTHENTICATION & USER MANAGEMENT
-- ============================================================================

-- Employer Users (Admin, HR, Managers, etc.)
CREATE TABLE employer_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_id INT NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    role ENUM('super_admin', 'admin', 'hr_manager', 'payroll_officer', 'department_manager', 'recruiter') NOT NULL,
    employee_id INT NULL, -- If employer user is also an employee
    profile_photo VARCHAR(255),
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    two_factor_secret VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    email_verified_at DATETIME,
    last_login DATETIME,
    last_login_ip VARCHAR(45),
    failed_login_attempts INT DEFAULT 0,
    locked_until DATETIME NULL,
    password_reset_token VARCHAR(255),
    password_reset_expires DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_org_active (organization_id, is_active),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee Users (Self-service portal)
CREATE TABLE employee_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL UNIQUE,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    pin_hash VARCHAR(255), -- For mobile/quick access
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    two_factor_secret VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    email_verified_at DATETIME,
    last_login DATETIME,
    last_login_ip VARCHAR(45),
    last_login_device VARCHAR(255),
    failed_login_attempts INT DEFAULT 0,
    locked_until DATETIME NULL,
    password_reset_token VARCHAR(255),
    password_reset_expires DATETIME,
    force_password_change BOOLEAN DEFAULT TRUE, -- Force change on first login
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_employee (employee_id),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Session Management (for both user types)
CREATE TABLE user_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_type ENUM('employer', 'employee') NOT NULL,
    user_id INT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    device_type VARCHAR(50),
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    logout_time DATETIME,
    INDEX idx_session_token (session_token),
    INDEX idx_user_type_id (user_type, user_id),
    INDEX idx_expires (expires_at),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Login Activity Log
CREATE TABLE login_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_type ENUM('employer', 'employee') NOT NULL,
    user_id INT NOT NULL,
    username VARCHAR(100),
    email VARCHAR(255),
    login_status ENUM('success', 'failed', 'locked', 'blocked') NOT NULL,
    failure_reason VARCHAR(255),
    ip_address VARCHAR(45),
    user_agent TEXT,
    device_type VARCHAR(50),
    location VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_type_id (user_type, user_id),
    INDEX idx_status (login_status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Permissions (Role-based Access Control)
CREATE TABLE user_permissions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_type ENUM('employer', 'employee') NOT NULL,
    user_id INT NOT NULL,
    permission_key VARCHAR(100) NOT NULL,
    permission_value BOOLEAN DEFAULT TRUE,
    granted_by INT,
    granted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NULL,
    UNIQUE KEY unique_user_permission (user_type, user_id, permission_key),
    INDEX idx_user_type_id (user_type, user_id),
    INDEX idx_permission_key (permission_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 3: DEPARTMENTS & POSITIONS
-- ============================================================================

-- Departments
CREATE TABLE departments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL,
    description TEXT,
    head_employee_id INT,
    parent_department_id INT,
    cost_center_code VARCHAR(50),
    budget DECIMAL(15, 2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_department_id) REFERENCES departments(id) ON DELETE SET NULL,
    UNIQUE KEY unique_org_dept_code (organization_id, code),
    INDEX idx_org_active (organization_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Positions/Job Titles
CREATE TABLE positions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_id INT NOT NULL,
    department_id INT,
    title VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL,
    job_description TEXT,
    requirements TEXT,
    minimum_salary DECIMAL(12, 2),
    maximum_salary DECIMAL(12, 2),
    job_level ENUM('entry', 'junior', 'mid', 'senior', 'lead', 'manager', 'director', 'executive') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    UNIQUE KEY unique_org_position_code (organization_id, code),
    INDEX idx_org_dept (organization_id, department_id),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 4: EMPLOYEE MANAGEMENT
-- ============================================================================

-- Employees (Core employee data)
CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_id INT NOT NULL,
    employee_number VARCHAR(50) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    
    -- Personal Information
    national_id VARCHAR(20) UNIQUE NOT NULL,
    kra_pin VARCHAR(20) UNIQUE NOT NULL,
    shif_number VARCHAR(50),
    nssf_number VARCHAR(50),
    date_of_birth DATE NOT NULL,
    gender ENUM('male', 'female', 'other') NOT NULL,
    marital_status ENUM('single', 'married', 'divorced', 'widowed'),
    nationality VARCHAR(100) DEFAULT 'Kenyan',
    passport_number VARCHAR(50),
    
    -- Contact Information
    phone_number VARCHAR(20) NOT NULL,
    personal_email VARCHAR(255),
    work_email VARCHAR(255),
    postal_address VARCHAR(255),
    residential_address TEXT,
    county VARCHAR(100),
    sub_county VARCHAR(100),
    
    -- Employment Details
    department_id INT,
    position_id INT,
    manager_id INT,
    employment_type ENUM('permanent', 'contract', 'intern', 'casual', 'part_time') NOT NULL,
    employment_status ENUM('active', 'on_leave', 'suspended', 'terminated', 'retired', 'probation') DEFAULT 'active',
    hire_date DATE NOT NULL,
    probation_end_date DATE,
    contract_start_date DATE,
    contract_end_date DATE,
    termination_date DATE,
    termination_reason TEXT,
    
    -- Other
    profile_photo VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (position_id) REFERENCES positions(id) ON DELETE SET NULL,
    FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE SET NULL,
    UNIQUE KEY unique_org_emp_number (organization_id, employee_number),
    INDEX idx_org_status (organization_id, employment_status),
    INDEX idx_department (department_id),
    INDEX idx_manager (manager_id),
    INDEX idx_national_id (national_id),
    INDEX idx_kra_pin (kra_pin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add foreign key after employees table is created
ALTER TABLE employee_users
    ADD FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE;

ALTER TABLE employer_users
    ADD FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL;

ALTER TABLE departments
    ADD FOREIGN KEY (head_employee_id) REFERENCES employees(id) ON DELETE SET NULL;

-- Bank and Payment Details
CREATE TABLE employee_bank_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    payment_method ENUM('bank', 'mpesa', 'cash', 'cheque') NOT NULL,
    bank_name VARCHAR(100),
    bank_code VARCHAR(20),
    branch_name VARCHAR(100),
    branch_code VARCHAR(20),
    account_number VARCHAR(50),
    account_name VARCHAR(255),
    mpesa_number VARCHAR(20),
    mpesa_name VARCHAR(255),
    is_primary BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    INDEX idx_employee (employee_id),
    INDEX idx_is_primary (is_primary)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Next of Kin
CREATE TABLE next_of_kin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    relationship VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    email VARCHAR(255),
    national_id VARCHAR(20),
    residential_address TEXT,
    postal_address VARCHAR(255),
    county VARCHAR(100),
    is_primary BOOLEAN DEFAULT FALSE,
    is_beneficiary BOOLEAN DEFAULT FALSE,
    beneficiary_percentage DECIMAL(5, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    INDEX idx_employee (employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee Documents
CREATE TABLE employee_documents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    document_type ENUM('contract', 'id_copy', 'certificate', 'cv', 'kra_pin', 'nssf', 'shif', 'other') NOT NULL,
    document_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    uploaded_by INT,
    upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    expiry_date DATE,
    notes TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by INT,
    verified_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    INDEX idx_employee (employee_id),
    INDEX idx_document_type (document_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 5: PAYROLL MANAGEMENT
-- ============================================================================

-- Salary Structures
CREATE TABLE salary_structures (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    basic_salary DECIMAL(12, 2) NOT NULL,
    housing_allowance DECIMAL(12, 2) DEFAULT 0.00,
    transport_allowance DECIMAL(12, 2) DEFAULT 0.00,
    medical_allowance DECIMAL(12, 2) DEFAULT 0.00,
    meal_allowance DECIMAL(12, 2) DEFAULT 0.00,
    communication_allowance DECIMAL(12, 2) DEFAULT 0.00,
    risk_allowance DECIMAL(12, 2) DEFAULT 0.00,
    other_allowances DECIMAL(12, 2) DEFAULT 0.00,
    allowances_description TEXT,
    effective_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    INDEX idx_employee_active (employee_id, is_active),
    INDEX idx_effective_date (effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payroll Records
CREATE TABLE payroll (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_id INT NOT NULL,
    employee_id INT NOT NULL,
    payroll_period_id INT,
    period_month TINYINT NOT NULL,
    period_year SMALLINT NOT NULL,
    
    -- Earnings
    basic_salary DECIMAL(12, 2) NOT NULL,
    housing_allowance DECIMAL(12, 2) DEFAULT 0.00,
    transport_allowance DECIMAL(12, 2) DEFAULT 0.00,
    medical_allowance DECIMAL(12, 2) DEFAULT 0.00,
    meal_allowance DECIMAL(12, 2) DEFAULT 0.00,
    communication_allowance DECIMAL(12, 2) DEFAULT 0.00,
    risk_allowance DECIMAL(12, 2) DEFAULT 0.00,
    other_allowances DECIMAL(12, 2) DEFAULT 0.00,
    
    -- Time-based earnings
    overtime_hours DECIMAL(5, 2) DEFAULT 0.00,
    overtime_pay DECIMAL(12, 2) DEFAULT 0.00,
    bonus DECIMAL(12, 2) DEFAULT 0.00,
    commission DECIMAL(12, 2) DEFAULT 0.00,
    
    -- Attendance deductions
    days_worked DECIMAL(5, 2) DEFAULT 0.00,
    days_absent DECIMAL(5, 2) DEFAULT 0.00,
    absence_deduction DECIMAL(12, 2) DEFAULT 0.00,
    late_deduction DECIMAL(12, 2) DEFAULT 0.00,
    
    -- Total earnings
    gross_pay DECIMAL(12, 2) NOT NULL,
    taxable_income DECIMAL(12, 2) NOT NULL,
    
    -- Statutory deductions (Kenya-specific)
    paye DECIMAL(12, 2) DEFAULT 0.00,
    nssf_employee DECIMAL(12, 2) DEFAULT 0.00,
    nssf_employer DECIMAL(12, 2) DEFAULT 0.00,
    shif DECIMAL(12, 2) DEFAULT 0.00,
    housing_levy DECIMAL(12, 2) DEFAULT 0.00,
    personal_relief DECIMAL(12, 2) DEFAULT 2400.00,
    insurance_relief DECIMAL(12, 2) DEFAULT 0.00,
    
    -- Other deductions
    loan_deduction DECIMAL(12, 2) DEFAULT 0.00,
    advance_deduction DECIMAL(12, 2) DEFAULT 0.00,
    pension_contribution DECIMAL(12, 2) DEFAULT 0.00,
    welfare_contribution DECIMAL(12, 2) DEFAULT 0.00,
    other_deductions DECIMAL(12, 2) DEFAULT 0.00,
    
    -- Totals
    total_deductions DECIMAL(12, 2) NOT NULL,
    net_pay DECIMAL(12, 2) NOT NULL,
    
    -- Payment details
    payment_status ENUM('pending', 'approved', 'paid', 'rejected', 'cancelled') DEFAULT 'pending',
    payment_method ENUM('bank', 'mpesa', 'cash', 'cheque') DEFAULT 'bank',
    payment_date DATE,
    payment_reference VARCHAR(100),
    
    -- Metadata
    calculated_by INT,
    calculated_at DATETIME,
    approved_by INT,
    approved_at DATETIME,
    paid_by INT,
    paid_at DATETIME,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY unique_employee_period (employee_id, period_month, period_year),
    INDEX idx_org_period (organization_id, period_year, period_month),
    INDEX idx_employee (employee_id),
    INDEX idx_status (payment_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payroll Periods
CREATE TABLE payroll_periods (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_id INT NOT NULL,
    period_name VARCHAR(100) NOT NULL,
    period_month TINYINT NOT NULL,
    period_year SMALLINT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    payment_date DATE NOT NULL,
    status ENUM('open', 'processing', 'approved', 'paid', 'closed') DEFAULT 'open',
    total_employees INT DEFAULT 0,
    total_gross_pay DECIMAL(15, 2) DEFAULT 0.00,
    total_deductions DECIMAL(15, 2) DEFAULT 0.00,
    total_net_pay DECIMAL(15, 2) DEFAULT 0.00,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    UNIQUE KEY unique_org_period (organization_id, period_year, period_month),
    INDEX idx_org_status (organization_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 6: ATTENDANCE & LEAVE MANAGEMENT
-- ============================================================================

-- Attendance Records
CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    check_in_time TIME,
    check_out_time TIME,
    check_in_location VARCHAR(255),
    check_out_location VARCHAR(255),
    status ENUM('present', 'absent', 'late', 'half_day', 'leave', 'holiday', 'weekend') DEFAULT 'present',
    work_hours DECIMAL(5, 2) DEFAULT 0.00,
    overtime_hours DECIMAL(5, 2) DEFAULT 0.00,
    late_minutes INT DEFAULT 0,
    notes TEXT,
    verified_by INT,
    verified_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY unique_employee_date (employee_id, attendance_date),
    INDEX idx_employee (employee_id),
    INDEX idx_date (attendance_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Leave Types
CREATE TABLE leave_types (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50) NOT NULL,
    description TEXT,
    days_per_year INT NOT NULL,
    is_paid BOOLEAN DEFAULT TRUE,
    requires_approval BOOLEAN DEFAULT TRUE,
    max_consecutive_days INT,
    min_notice_days INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    UNIQUE KEY unique_org_leave_code (organization_id, code),
    INDEX idx_org_active (organization_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Leave Balance
CREATE TABLE leave_balance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    year SMALLINT NOT NULL,
    total_days DECIMAL(5, 2) NOT NULL,
    used_days DECIMAL(5, 2) DEFAULT 0.00,
    remaining_days DECIMAL(5, 2) NOT NULL,
    carried_forward DECIMAL(5, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id) ON DELETE CASCADE,
    UNIQUE KEY unique_employee_leave_year (employee_id, leave_type_id, year),
    INDEX idx_employee (employee_id),
    INDEX idx_year (year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Leave Applications
CREATE TABLE leave_applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days_requested DECIMAL(5, 2) NOT NULL,
    reason TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    applied_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    approved_by INT,
    approved_date DATETIME,
    rejection_reason TEXT,
    handover_notes TEXT,
    emergency_contact VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id) ON DELETE CASCADE,
    INDEX idx_employee (employee_id),
    INDEX idx_status (status),
    INDEX idx_dates (start_date, end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 7: AUDIT & SYSTEM LOGS
-- ============================================================================

-- Audit Log (Track all important changes)
CREATE TABLE audit_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_type ENUM('employer', 'employee', 'system') NOT NULL,
    user_id INT,
    username VARCHAR(100),
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100) NOT NULL,
    record_id INT,
    old_values TEXT,
    new_values TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_type_id (user_type, user_id),
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- System Settings
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organization_id INT,
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT,
    setting_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_org_setting (organization_id, setting_key),
    INDEX idx_organization (organization_id),
    INDEX idx_setting_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 8: INITIAL DATA & DEFAULT VALUES
-- ============================================================================

-- Insert default organization (if needed)
INSERT INTO organizations (organization_name, organization_code, email, country, is_active) 
VALUES ('Default Organization', 'ORG001', 'admin@example.com', 'Kenya', TRUE);

-- Insert default leave types for Kenya
SET @org_id = LAST_INSERT_ID();

INSERT INTO leave_types (organization_id, name, code, description, days_per_year, is_paid, is_active) VALUES
(@org_id, 'Annual Leave', 'ANNUAL', 'Annual paid leave as per Employment Act', 21, TRUE, TRUE),
(@org_id, 'Sick Leave', 'SICK', 'Sick leave with medical certificate', 30, TRUE, TRUE),
(@org_id, 'Maternity Leave', 'MATERNITY', 'Maternity leave for female employees', 90, TRUE, TRUE),
(@org_id, 'Paternity Leave', 'PATERNITY', 'Paternity leave for male employees', 14, TRUE, TRUE),
(@org_id, 'Compassionate Leave', 'COMPASSIONATE', 'Compassionate leave for family emergencies', 5, TRUE, TRUE),
(@org_id, 'Study Leave', 'STUDY', 'Study leave for educational purposes', 10, FALSE, TRUE),
(@org_id, 'Unpaid Leave', 'UNPAID', 'Unpaid leave', 0, FALSE, TRUE);

-- Insert default system settings
INSERT INTO system_settings (organization_id, setting_key, setting_value, setting_type, description, is_public) VALUES
(@org_id, 'paye_personal_relief', '2400', 'number', 'Monthly PAYE personal relief (KES)', FALSE),
(@org_id, 'housing_levy_rate', '1.5', 'number', 'Housing levy rate (%)', FALSE),
(@org_id, 'nssf_tier1_limit', '7000', 'number', 'NSSF Tier 1 limit (KES)', FALSE),
(@org_id, 'nssf_tier2_limit', '36000', 'number', 'NSSF Tier 2 limit (KES)', FALSE),
(@org_id, 'working_hours_per_day', '8', 'number', 'Standard working hours per day', FALSE),
(@org_id, 'overtime_rate', '1.5', 'number', 'Overtime multiplier rate', FALSE),
(@org_id, 'enable_employee_portal', 'true', 'boolean', 'Enable employee self-service portal', TRUE),
(@org_id, 'enable_mobile_app', 'true', 'boolean', 'Enable mobile app access', TRUE),
(@org_id, 'password_min_length', '8', 'number', 'Minimum password length', FALSE),
(@org_id, 'session_timeout_minutes', '60', 'number', 'Session timeout in minutes', FALSE);

-- ============================================================================
-- SECTION 9: VIEWS FOR EASY DATA ACCESS
-- ============================================================================

-- View: Active Employees with Department and Position
CREATE VIEW view_active_employees AS
SELECT 
    e.id,
    e.organization_id,
    e.employee_number,
    CONCAT(e.first_name, ' ', COALESCE(e.middle_name, ''), ' ', e.last_name) AS full_name,
    e.phone_number,
    e.work_email,
    d.name AS department_name,
    p.title AS position_title,
    e.employment_type,
    e.hire_date,
    CONCAT(m.first_name, ' ', m.last_name) AS manager_name
FROM employees e
LEFT JOIN departments d ON e.department_id = d.id
LEFT JOIN positions p ON e.position_id = p.id
LEFT JOIN employees m ON e.manager_id = m.id
WHERE e.employment_status = 'active';

-- View: Current Month Payroll Summary
CREATE VIEW view_current_payroll_summary AS
SELECT 
    p.organization_id,
    p.period_month,
    p.period_year,
    COUNT(p.id) AS total_employees,
    SUM(p.gross_pay) AS total_gross_pay,
    SUM(p.paye) AS total_paye,
    SUM(p.nssf_employee) AS total_nssf_employee,
    SUM(p.nssf_employer) AS total_nssf_employer,
    SUM(p.shif) AS total_shif,
    SUM(p.housing_levy) AS total_housing_levy,
    SUM(p.total_deductions) AS total_deductions,
    SUM(p.net_pay) AS total_net_pay
FROM payroll p
WHERE p.period_year = YEAR(CURDATE()) 
  AND p.period_month = MONTH(CURDATE())
GROUP BY p.organization_id, p.period_month, p.period_year;

-- View: Leave Balance Summary
CREATE VIEW view_leave_balance_summary AS
SELECT 
    e.id AS employee_id,
    e.employee_number,
    CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
    lt.name AS leave_type,
    lb.year,
    lb.total_days,
    lb.used_days,
    lb.remaining_days,
    lb.carried_forward
FROM leave_balance lb
JOIN employees e ON lb.employee_id = e.id
JOIN leave_types lt ON lb.leave_type_id = lt.id
WHERE e.employment_status = 'active';

-- ============================================================================
-- SECTION 10: INDEXES FOR PERFORMANCE
-- ============================================================================

-- Additional composite indexes for common queries
CREATE INDEX idx_emp_org_status ON employees(organization_id, employment_status, department_id);
CREATE INDEX idx_payroll_org_period_status ON payroll(organization_id, period_year, period_month, payment_status);
CREATE INDEX idx_attendance_emp_date_status ON attendance(employee_id, attendance_date, status);
CREATE INDEX idx_leave_emp_status ON leave_applications(employee_id, status, start_date);

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
