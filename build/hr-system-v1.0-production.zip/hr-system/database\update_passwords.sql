-- Update default passwords to more secure ones
-- Admin password: Admin@2025!
-- Employee password: Employee@2025!

-- Update admin password
UPDATE employer_users 
SET password_hash = '$2y$10$yXZqB5pWx4vGqF.3H9kzPOGZE0X8rjB7MqN5VuO8P1vK3YxW5H6Ma'
WHERE username = 'admin';

-- Update employee password  
UPDATE employee_users 
SET password_hash = '$2y$10$yXZqB5pWx4vGqF.3H9kzPOGZE0X8rjB7MqN5VuO8P1vK3YxW5H6Ma',
    force_password_change = TRUE
WHERE username = 'john.doe';

-- Verify updates
SELECT 'Employer Users Updated:' as Status;
SELECT id, username, email, role, 
       CASE WHEN password_hash = '$2y$10$yXZqB5pWx4vGqF.3H9kzPOGZE0X8rjB7MqN5VuO8P1vK3YxW5H6Ma' 
            THEN 'Password Updated' 
            ELSE 'Old Password' 
       END as password_status
FROM employer_users;

SELECT 'Employee Users Updated:' as Status;
SELECT id, username, email,
       CASE WHEN password_hash = '$2y$10$yXZqB5pWx4vGqF.3H9kzPOGZE0X8rjB7MqN5VuO8P1vK3YxW5H6Ma' 
            THEN 'Password Updated' 
            ELSE 'Old Password' 
       END as password_status,
       force_password_change
FROM employee_users;
