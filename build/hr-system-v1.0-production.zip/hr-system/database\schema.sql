-- HR Management System Database Schema
-- Kenyan Compliance: SHIF, NSSF, KRA, Employment Act 2007

-- Users and Authentication
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'hr_manager', 'manager', 'employee') NOT NULL,
    employee_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL
);

-- Employee Database
CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_number VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    national_id VARCHAR(20) UNIQUE NOT NULL,
    kra_pin VARCHAR(20) UNIQUE NOT NULL,
    shif_number VARCHAR(50),
    nssf_number VARCHAR(50),
    date_of_birth DATE NOT NULL,
    gender ENUM('male', 'female', 'other') NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    personal_email VARCHAR(255),
    work_email VARCHAR(255),
    postal_address VARCHAR(255),
    residential_address TEXT,
    county VARCHAR(100),
    sub_county VARCHAR(100),
    marital_status ENUM('single', 'married', 'divorced', 'widowed'),
    nationality VARCHAR(100) DEFAULT 'Kenyan',
    passport_number VARCHAR(50),
    profile_photo VARCHAR(255),
    department_id INT,
    position_id INT,
    manager_id INT,
    employment_type ENUM('permanent', 'contract', 'intern', 'casual') NOT NULL,
    employment_status ENUM('active', 'on_leave', 'suspended', 'terminated', 'retired') DEFAULT 'active',
    hire_date DATE NOT NULL,
    probation_end_date DATE,
    contract_end_date DATE,
    termination_date DATE,
    termination_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (position_id) REFERENCES positions(id),
    FOREIGN KEY (manager_id) REFERENCES employees(id)
);

-- Bank and Payment Details
CREATE TABLE employee_bank_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    payment_method ENUM('bank', 'mpesa', 'cash') NOT NULL,
    bank_name VARCHAR(100),
    branch_name VARCHAR(100),
    account_number VARCHAR(50),
    account_name VARCHAR(255),
    mpesa_number VARCHAR(20),
    is_primary BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Next of Kin
CREATE TABLE next_of_kin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    relationship VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    email VARCHAR(255),
    national_id VARCHAR(20),
    residential_address TEXT,
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Departments
CREATE TABLE departments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    head_id INT,
    parent_department_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (head_id) REFERENCES employees(id),
    FOREIGN KEY (parent_department_id) REFERENCES departments(id)
);

-- Positions
CREATE TABLE positions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    department_id INT,
    job_description TEXT,
    requirements TEXT,
    minimum_salary DECIMAL(12, 2),
    maximum_salary DECIMAL(12, 2),
    job_level ENUM('entry', 'junior', 'mid', 'senior', 'lead', 'manager', 'executive') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id)
);

-- Recruitment Management
CREATE TABLE job_postings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    position_id INT NOT NULL,
    job_title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    requirements TEXT NOT NULL,
    application_deadline DATE NOT NULL,
    vacancies INT DEFAULT 1,
    employment_type ENUM('permanent', 'contract', 'intern', 'casual') NOT NULL,
    salary_range VARCHAR(100),
    location VARCHAR(255),
    status ENUM('draft', 'published', 'closed', 'cancelled') DEFAULT 'draft',
    brightermonday_url VARCHAR(500),
    linkedin_url VARCHAR(500),
    company_website_url VARCHAR(500),
    posted_by INT,
    posted_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (position_id) REFERENCES positions(id),
    FOREIGN KEY (posted_by) REFERENCES users(id)
);

-- Applicant Tracking
CREATE TABLE applicants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    job_posting_id INT NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    cv_file_path VARCHAR(500),
    cover_letter TEXT,
    linkedin_profile VARCHAR(500),
    years_of_experience INT,
    education_level VARCHAR(100),
    current_salary DECIMAL(12, 2),
    expected_salary DECIMAL(12, 2),
    notice_period VARCHAR(100),
    status ENUM('applied', 'screening', 'shortlisted', 'interview', 'offered', 'rejected', 'withdrawn') DEFAULT 'applied',
    ranking_score DECIMAL(5, 2),
    notes TEXT,
    applied_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (job_posting_id) REFERENCES job_postings(id)
);

-- Interview Tracking
CREATE TABLE interviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    applicant_id INT NOT NULL,
    interview_type ENUM('phone_screen', 'technical', 'hr', 'panel', 'final') NOT NULL,
    interview_date DATETIME NOT NULL,
    location VARCHAR(255),
    meeting_link VARCHAR(500),
    interviewer_ids TEXT,
    status ENUM('scheduled', 'completed', 'cancelled', 'no_show') DEFAULT 'scheduled',
    feedback TEXT,
    rating DECIMAL(3, 2),
    recommendation ENUM('strongly_recommended', 'recommended', 'neutral', 'not_recommended') ,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (applicant_id) REFERENCES applicants(id)
);

-- Onboarding
CREATE TABLE onboarding_checklists (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    contract_signed BOOLEAN DEFAULT FALSE,
    contract_signed_date DATE,
    kra_pin_verified BOOLEAN DEFAULT FALSE,
    shif_registered BOOLEAN DEFAULT FALSE,
    shif_registration_date DATE,
    nssf_registered BOOLEAN DEFAULT FALSE,
    nssf_registration_date DATE,
    bank_details_submitted BOOLEAN DEFAULT FALSE,
    emergency_contacts_submitted BOOLEAN DEFAULT FALSE,
    id_documents_submitted BOOLEAN DEFAULT FALSE,
    equipment_issued BOOLEAN DEFAULT FALSE,
    email_account_created BOOLEAN DEFAULT FALSE,
    system_access_granted BOOLEAN DEFAULT FALSE,
    orientation_completed BOOLEAN DEFAULT FALSE,
    orientation_date DATE,
    probation_letter_issued BOOLEAN DEFAULT FALSE,
    employee_handbook_acknowledged BOOLEAN DEFAULT FALSE,
    onboarding_status ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
    assigned_to INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES users(id)
);

-- Leave Management
CREATE TABLE leave_types (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    days_per_year INT NOT NULL,
    is_paid BOOLEAN DEFAULT TRUE,
    requires_medical_certificate BOOLEAN DEFAULT FALSE,
    max_consecutive_days INT,
    gender_specific ENUM('all', 'male', 'female') DEFAULT 'all',
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default leave types
INSERT INTO leave_types (name, code, days_per_year, is_paid, requires_medical_certificate, gender_specific, description) VALUES
('Annual Leave', 'ANNUAL', 21, TRUE, FALSE, 'all', 'Annual vacation leave as per Employment Act 2007'),
('Sick Leave', 'SICK', 14, TRUE, TRUE, 'all', 'Medical leave with certificate'),
('Maternity Leave', 'MATERNITY', 90, TRUE, FALSE, 'female', '3 months maternity leave for female employees'),
('Paternity Leave', 'PATERNITY', 14, TRUE, FALSE, 'male', '2 weeks paternity leave for male employees'),
('Compassionate Leave', 'COMPASSIONATE', 5, TRUE, FALSE, 'all', 'Leave due to death of immediate family member'),
('Study Leave', 'STUDY', 0, FALSE, FALSE, 'all', 'Leave for examinations or studies'),
('Unpaid Leave', 'UNPAID', 0, FALSE, FALSE, 'all', 'Leave without pay');

CREATE TABLE leave_applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days_requested DECIMAL(5, 2) NOT NULL,
    reason TEXT NOT NULL,
    supporting_document VARCHAR(500),
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    applied_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    reviewed_by INT,
    review_date DATETIME,
    review_comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
);

CREATE TABLE leave_balances (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    year INT NOT NULL,
    total_days DECIMAL(5, 2) NOT NULL,
    days_taken DECIMAL(5, 2) DEFAULT 0,
    days_pending DECIMAL(5, 2) DEFAULT 0,
    days_remaining DECIMAL(5, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_leave_year (employee_id, leave_type_id, year),
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id)
);

-- Attendance & Time Tracking
CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    clock_in DATETIME,
    clock_out DATETIME,
    clock_in_method ENUM('mobile', 'biometric', 'manual', 'web') DEFAULT 'manual',
    clock_out_method ENUM('mobile', 'biometric', 'manual', 'web') DEFAULT 'manual',
    clock_in_location VARCHAR(255),
    clock_out_location VARCHAR(255),
    clock_in_latitude DECIMAL(10, 8),
    clock_in_longitude DECIMAL(11, 8),
    clock_out_latitude DECIMAL(10, 8),
    clock_out_longitude DECIMAL(11, 8),
    work_hours DECIMAL(5, 2),
    overtime_hours DECIMAL(5, 2) DEFAULT 0,
    status ENUM('present', 'absent', 'late', 'half_day', 'on_leave', 'holiday') DEFAULT 'present',
    notes TEXT,
    approved_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_date (employee_id, attendance_date),
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- Biometric Device Integration
CREATE TABLE biometric_devices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_name VARCHAR(255) NOT NULL,
    device_serial VARCHAR(100) UNIQUE NOT NULL,
    device_type VARCHAR(100),
    location VARCHAR(255),
    ip_address VARCHAR(50),
    port INT,
    is_active BOOLEAN DEFAULT TRUE,
    last_sync DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Shift & Scheduling
CREATE TABLE shifts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_duration_minutes INT DEFAULT 60,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE shift_schedules (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    shift_id INT NOT NULL,
    schedule_date DATE NOT NULL,
    location VARCHAR(255),
    status ENUM('scheduled', 'confirmed', 'completed', 'cancelled') DEFAULT 'scheduled',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (shift_id) REFERENCES shifts(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Remote & Hybrid Work
CREATE TABLE remote_work_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    work_type ENUM('remote', 'hybrid') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    days_of_week VARCHAR(100),
    reason TEXT NOT NULL,
    work_location TEXT,
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    approved_by INT,
    approval_date DATETIME,
    comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- Compensation & Payroll
CREATE TABLE salary_structures (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    basic_salary DECIMAL(12, 2) NOT NULL,
    housing_allowance DECIMAL(12, 2) DEFAULT 0,
    transport_allowance DECIMAL(12, 2) DEFAULT 0,
    medical_allowance DECIMAL(12, 2) DEFAULT 0,
    risk_allowance DECIMAL(12, 2) DEFAULT 0,
    other_allowances DECIMAL(12, 2) DEFAULT 0,
    gross_salary DECIMAL(12, 2) NOT NULL,
    effective_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);

CREATE TABLE payroll (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    period_month INT NOT NULL,
    period_year INT NOT NULL,
    basic_salary DECIMAL(12, 2) NOT NULL,
    housing_allowance DECIMAL(12, 2) DEFAULT 0,
    transport_allowance DECIMAL(12, 2) DEFAULT 0,
    medical_allowance DECIMAL(12, 2) DEFAULT 0,
    overtime_pay DECIMAL(12, 2) DEFAULT 0,
    bonus DECIMAL(12, 2) DEFAULT 0,
    other_earnings DECIMAL(12, 2) DEFAULT 0,
    gross_pay DECIMAL(12, 2) NOT NULL,
    paye DECIMAL(12, 2) DEFAULT 0,
    shif_deduction DECIMAL(12, 2) DEFAULT 0,
    nssf_deduction DECIMAL(12, 2) DEFAULT 0,
    housing_levy DECIMAL(12, 2) DEFAULT 0,
    loans DECIMAL(12, 2) DEFAULT 0,
    advances DECIMAL(12, 2) DEFAULT 0,
    other_deductions DECIMAL(12, 2) DEFAULT 0,
    total_deductions DECIMAL(12, 2) NOT NULL,
    net_pay DECIMAL(12, 2) NOT NULL,
    status ENUM('draft', 'processed', 'approved', 'paid') DEFAULT 'draft',
    payment_date DATE,
    processed_by INT,
    approved_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_period (employee_id, period_month, period_year),
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (processed_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- Benefits Administration
CREATE TABLE employee_benefits (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    shif_number VARCHAR(50),
    shif_registration_date DATE,
    shif_principal_member BOOLEAN DEFAULT TRUE,
    nssf_number VARCHAR(50),
    nssf_registration_date DATE,
    sha_number VARCHAR(50),
    sha_registration_date DATE,
    insurance_provider VARCHAR(255),
    insurance_policy_number VARCHAR(100),
    insurance_start_date DATE,
    insurance_end_date DATE,
    pension_scheme VARCHAR(255),
    pension_member_number VARCHAR(100),
    pension_contribution_rate DECIMAL(5, 2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Expense & Reimbursements
CREATE TABLE expense_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    requires_receipt BOOLEAN DEFAULT TRUE,
    max_amount DECIMAL(12, 2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO expense_categories (name, code, requires_receipt) VALUES
('Petty Cash', 'PETTY_CASH', TRUE),
('Airtime', 'AIRTIME', TRUE),
('Travel', 'TRAVEL', TRUE),
('Accommodation', 'ACCOMMODATION', TRUE),
('Meals', 'MEALS', TRUE),
('Fuel', 'FUEL', TRUE),
('Stationery', 'STATIONERY', TRUE),
('Other', 'OTHER', TRUE);

CREATE TABLE expense_claims (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    expense_category_id INT NOT NULL,
    claim_date DATE NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    description TEXT NOT NULL,
    receipt_file_path VARCHAR(500),
    status ENUM('pending', 'approved', 'rejected', 'paid') DEFAULT 'pending',
    reviewed_by INT,
    review_date DATETIME,
    review_comments TEXT,
    payment_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (expense_category_id) REFERENCES expense_categories(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
);

-- Performance Reviews
CREATE TABLE performance_review_templates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    review_period ENUM('monthly', 'quarterly', 'semi_annual', 'annual') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE performance_kpis (
    id INT PRIMARY KEY AUTO_INCREMENT,
    template_id INT NOT NULL,
    kpi_name VARCHAR(255) NOT NULL,
    description TEXT,
    weight DECIMAL(5, 2) NOT NULL,
    measurement_criteria TEXT,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (template_id) REFERENCES performance_review_templates(id)
);

CREATE TABLE performance_reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    reviewer_id INT NOT NULL,
    template_id INT NOT NULL,
    review_period_start DATE NOT NULL,
    review_period_end DATE NOT NULL,
    overall_rating DECIMAL(3, 2),
    overall_score DECIMAL(5, 2),
    strengths TEXT,
    areas_for_improvement TEXT,
    goals_next_period TEXT,
    employee_comments TEXT,
    status ENUM('draft', 'submitted', 'employee_acknowledged', 'completed') DEFAULT 'draft',
    review_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (reviewer_id) REFERENCES employees(id),
    FOREIGN KEY (template_id) REFERENCES performance_review_templates(id)
);

CREATE TABLE performance_review_ratings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    review_id INT NOT NULL,
    kpi_id INT NOT NULL,
    rating DECIMAL(3, 2) NOT NULL,
    score DECIMAL(5, 2) NOT NULL,
    comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (review_id) REFERENCES performance_reviews(id) ON DELETE CASCADE,
    FOREIGN KEY (kpi_id) REFERENCES performance_kpis(id)
);

-- Learning & Development
CREATE TABLE training_programs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    program_name VARCHAR(255) NOT NULL,
    provider VARCHAR(255),
    description TEXT,
    training_type ENUM('internal', 'external', 'online', 'nita_approved') NOT NULL,
    cost DECIMAL(12, 2),
    nita_levy_utilized BOOLEAN DEFAULT FALSE,
    duration_days INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_enrollments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    training_program_id INT NOT NULL,
    enrollment_date DATE NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    completion_date DATE,
    status ENUM('enrolled', 'in_progress', 'completed', 'cancelled') DEFAULT 'enrolled',
    certificate_issued BOOLEAN DEFAULT FALSE,
    certificate_file_path VARCHAR(500),
    feedback TEXT,
    rating DECIMAL(3, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (training_program_id) REFERENCES training_programs(id)
);

-- Succession Planning
CREATE TABLE succession_plans (
    id INT PRIMARY KEY AUTO_INCREMENT,
    position_id INT NOT NULL,
    critical_level ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    time_horizon ENUM('immediate', 'short_term', 'medium_term', 'long_term') NOT NULL,
    risk_assessment TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (position_id) REFERENCES positions(id)
);

CREATE TABLE succession_candidates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    succession_plan_id INT NOT NULL,
    employee_id INT NOT NULL,
    readiness_level ENUM('ready_now', 'ready_1_year', 'ready_2_years', 'ready_3plus_years') NOT NULL,
    development_needs TEXT,
    status ENUM('identified', 'in_development', 'ready', 'promoted', 'removed') DEFAULT 'identified',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (succession_plan_id) REFERENCES succession_plans(id),
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);

-- Disciplinary Records
CREATE TABLE disciplinary_cases (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    case_number VARCHAR(50) UNIQUE NOT NULL,
    case_type ENUM('verbal_warning', 'written_warning', 'final_warning', 'suspension', 'dismissal', 'other') NOT NULL,
    incident_date DATE NOT NULL,
    incident_description TEXT NOT NULL,
    policy_violated VARCHAR(255),
    reported_by INT,
    investigated_by INT,
    investigation_findings TEXT,
    action_taken TEXT,
    warning_issued_date DATE,
    warning_expiry_date DATE,
    status ENUM('reported', 'under_investigation', 'resolved', 'appealed', 'closed') DEFAULT 'reported',
    documents TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (reported_by) REFERENCES users(id),
    FOREIGN KEY (investigated_by) REFERENCES users(id)
);

-- Grievance Management
CREATE TABLE grievances (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    grievance_number VARCHAR(50) UNIQUE NOT NULL,
    grievance_type ENUM('harassment', 'discrimination', 'workplace_safety', 'compensation', 'workload', 'management', 'other') NOT NULL,
    description TEXT NOT NULL,
    date_filed DATE NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    assigned_to INT,
    investigation_notes TEXT,
    resolution TEXT,
    status ENUM('filed', 'under_review', 'investigating', 'resolved', 'escalated', 'closed') DEFAULT 'filed',
    resolved_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (assigned_to) REFERENCES users(id)
);

-- Health & Safety (OSHA/NITA)
CREATE TABLE safety_incidents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    incident_number VARCHAR(50) UNIQUE NOT NULL,
    incident_type ENUM('injury', 'near_miss', 'property_damage', 'illness', 'other') NOT NULL,
    incident_date DATETIME NOT NULL,
    location VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    employee_id INT,
    witness_ids TEXT,
    severity ENUM('minor', 'moderate', 'serious', 'critical', 'fatal') NOT NULL,
    immediate_action_taken TEXT,
    investigation_findings TEXT,
    corrective_actions TEXT,
    osha_reportable BOOLEAN DEFAULT FALSE,
    osha_report_date DATE,
    status ENUM('reported', 'under_investigation', 'resolved', 'closed') DEFAULT 'reported',
    reported_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (reported_by) REFERENCES users(id)
);

CREATE TABLE safety_drills (
    id INT PRIMARY KEY AUTO_INCREMENT,
    drill_type ENUM('fire', 'evacuation', 'first_aid', 'other') NOT NULL,
    drill_date DATE NOT NULL,
    location VARCHAR(255) NOT NULL,
    participants_count INT,
    duration_minutes INT,
    observations TEXT,
    areas_for_improvement TEXT,
    conducted_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conducted_by) REFERENCES users(id)
);

-- Policy & Document Management
CREATE TABLE documents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    document_type ENUM('policy', 'procedure', 'handbook', 'form', 'contract', 'other') NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    file_path VARCHAR(500) NOT NULL,
    version VARCHAR(50) DEFAULT '1.0',
    effective_date DATE,
    review_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    requires_acknowledgment BOOLEAN DEFAULT FALSE,
    uploaded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

CREATE TABLE document_acknowledgments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    document_id INT NOT NULL,
    employee_id INT NOT NULL,
    acknowledged_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(50),
    UNIQUE KEY unique_document_employee (document_id, employee_id),
    FOREIGN KEY (document_id) REFERENCES documents(id),
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);

-- Exit Management
CREATE TABLE exit_interviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    exit_date DATE NOT NULL,
    exit_type ENUM('resignation', 'termination', 'retirement', 'end_of_contract', 'other') NOT NULL,
    reason_for_leaving ENUM('better_pay', 'career_growth', 'migration', 'studies', 'relocation', 'retirement', 'health', 'other') NOT NULL,
    destination_country VARCHAR(100),
    destination_company VARCHAR(255),
    would_rejoin ENUM('yes', 'no', 'maybe') NOT NULL,
    would_recommend ENUM('yes', 'no', 'maybe') NOT NULL,
    salary_satisfaction INT,
    work_environment_satisfaction INT,
    management_satisfaction INT,
    growth_opportunities_satisfaction INT,
    work_life_balance_satisfaction INT,
    positive_feedback TEXT,
    areas_for_improvement TEXT,
    conducted_by INT,
    interview_date DATE,
    clearance_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (conducted_by) REFERENCES users(id)
);

-- Employee Engagement
CREATE TABLE engagement_surveys (
    id INT PRIMARY KEY AUTO_INCREMENT,
    survey_title VARCHAR(255) NOT NULL,
    description TEXT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    google_form_url VARCHAR(500),
    is_anonymous BOOLEAN DEFAULT TRUE,
    status ENUM('draft', 'active', 'closed') DEFAULT 'draft',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Recognition & Rewards
CREATE TABLE recognition_programs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    program_name VARCHAR(255) NOT NULL,
    program_type ENUM('employee_of_month', 'spot_award', 'milestone', 'performance', 'other') NOT NULL,
    description TEXT,
    reward_type ENUM('certificate', 'cash', 'gift', 'time_off', 'other') NOT NULL,
    reward_value DECIMAL(12, 2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE recognitions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    program_id INT NOT NULL,
    recognition_date DATE NOT NULL,
    reason TEXT NOT NULL,
    awarded_by INT,
    is_public BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (program_id) REFERENCES recognition_programs(id),
    FOREIGN KEY (awarded_by) REFERENCES users(id)
);

-- Wellness Programs
CREATE TABLE wellness_programs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    program_name VARCHAR(255) NOT NULL,
    program_type ENUM('mental_health', 'physical_fitness', 'health_screening', 'stress_management', 'other') NOT NULL,
    description TEXT,
    provider VARCHAR(255),
    start_date DATE,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE wellness_enrollments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    program_id INT NOT NULL,
    enrollment_date DATE NOT NULL,
    completion_date DATE,
    status ENUM('enrolled', 'active', 'completed', 'withdrawn') DEFAULT 'enrolled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (program_id) REFERENCES wellness_programs(id)
);

-- Internal Communication
CREATE TABLE announcements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    announcement_type ENUM('general', 'policy', 'event', 'urgent', 'celebration') DEFAULT 'general',
    target_audience ENUM('all', 'department', 'position', 'specific') DEFAULT 'all',
    department_id INT,
    position_id INT,
    priority ENUM('low', 'normal', 'high') DEFAULT 'normal',
    publish_date DATETIME NOT NULL,
    expiry_date DATETIME,
    attachment_path VARCHAR(500),
    is_published BOOLEAN DEFAULT FALSE,
    posted_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (position_id) REFERENCES positions(id),
    FOREIGN KEY (posted_by) REFERENCES users(id)
);

-- Headcount Forecasting
CREATE TABLE headcount_forecasts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    department_id INT NOT NULL,
    position_id INT,
    forecast_year INT NOT NULL,
    forecast_quarter INT NOT NULL,
    current_headcount INT NOT NULL,
    projected_headcount INT NOT NULL,
    business_justification TEXT,
    budget_allocated DECIMAL(12, 2),
    status ENUM('draft', 'submitted', 'approved', 'rejected') DEFAULT 'draft',
    created_by INT,
    approved_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (position_id) REFERENCES positions(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- Audit Log
CREATE TABLE audit_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100) NOT NULL,
    record_id INT,
    old_values TEXT,
    new_values TEXT,
    ip_address VARCHAR(50),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- System Settings
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type VARCHAR(50),
    description TEXT,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(id)
);

-- Default system settings
INSERT INTO system_settings (setting_key, setting_value, setting_type, description) VALUES
('company_name', 'Your Company Ltd', 'text', 'Company name'),
('company_kra_pin', '', 'text', 'Company KRA PIN'),
('company_nssf_number', '', 'text', 'Company NSSF number'),
('company_shif_number', '', 'text', 'Company SHIF number'),
('min_wage_kenya', '15000', 'number', 'Kenya minimum wage in KES'),
('work_hours_per_day', '8', 'number', 'Standard work hours per day'),
('work_days_per_week', '5', 'number', 'Standard work days per week'),
('overtime_rate', '1.5', 'number', 'Overtime pay multiplier');
