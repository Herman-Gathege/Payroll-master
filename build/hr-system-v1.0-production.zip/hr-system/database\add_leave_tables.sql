-- Add Leave Management Tables
-- Run this after the main schema.sql

-- Leave Requests Table
CREATE TABLE IF NOT EXISTS leave_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT NOT NULL,
    reason TEXT,
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    approved_by INT,
    approved_at DATETIME,
    rejection_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_employee_id (employee_id),
    INDEX idx_status (status),
    INDEX idx_dates (start_date, end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Leave Balance Table (Optional - for tracking entitlements)
CREATE TABLE IF NOT EXISTS leave_balance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    year INT NOT NULL,
    annual_leave_total INT DEFAULT 21,
    annual_leave_used INT DEFAULT 0,
    sick_leave_total INT DEFAULT 14,
    sick_leave_used INT DEFAULT 0,
    maternity_leave_total INT DEFAULT 90,
    maternity_leave_used INT DEFAULT 0,
    paternity_leave_total INT DEFAULT 14,
    paternity_leave_used INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY unique_employee_year (employee_id, year),
    INDEX idx_employee_year (employee_id, year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert initial leave balance for all active employees for current year
INSERT INTO leave_balance (employee_id, year, annual_leave_total, sick_leave_total, maternity_leave_total, paternity_leave_total)
SELECT
    id,
    YEAR(CURDATE()),
    21,
    14,
    90,
    14
FROM employees
WHERE employment_status = 'active'
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- Add some sample leave requests (optional - for testing)
-- Uncomment if you want test data
/*
INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, days, reason, status) VALUES
(1, 'Annual Leave', '2025-11-15', '2025-11-20', 6, 'Family vacation', 'approved'),
(1, 'Sick Leave', '2025-10-05', '2025-10-06', 2, 'Medical appointment', 'approved'),
(2, 'Annual Leave', '2025-12-20', '2025-12-27', 8, 'Christmas holiday', 'pending');
*/
