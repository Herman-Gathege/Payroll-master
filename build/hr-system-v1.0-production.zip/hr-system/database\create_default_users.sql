-- Create default admin user
INSERT INTO employer_users (
    organization_id, username, email, password_hash,
    first_name, last_name, role, is_active, email_verified
) VALUES (
    1, 'admin', 'admin@company.com',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'System', 'Administrator', 'super_admin', TRUE, TRUE
);

-- Create sample employee
INSERT INTO employees (
    organization_id, employee_number, first_name, last_name,
    national_id, kra_pin, date_of_birth, gender, phone_number,
    work_email, employment_type, employment_status, hire_date
) VALUES (
    1, 'EMP001', 'John', 'Doe',
    '12345678', 'A123456789Z', '1990-01-01', 'male', '0712345678',
    'john.doe@company.com', 'permanent', 'active', CURDATE()
);

-- Create employee user account
INSERT INTO employee_users (
    employee_id, username, email, password_hash,
    is_active, force_password_change
)
SELECT 
    id, 'john.doe', work_email,
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    TRUE, TRUE
FROM employees
WHERE employee_number = 'EMP001';

-- Verify users created
SELECT 'Employer Users Created:' as Status;
SELECT id, username, email, role FROM employer_users;

SELECT 'Employee Users Created:' as Status;
SELECT eu.id, eu.username, eu.email, e.employee_number 
FROM employee_users eu
JOIN employees e ON eu.employee_id = e.id;
