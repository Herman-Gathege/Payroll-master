-- Fix login_logs table to allow NULL user_id for failed login attempts
-- This allows logging of login attempts for non-existent users

USE hr_management_system;

-- Modify user_id column to allow NULL values
ALTER TABLE login_logs
MODIFY COLUMN user_id INT NULL;

-- Add a comment explaining the change
ALTER TABLE login_logs
COMMENT = 'Login activity log - user_id can be NULL for failed login attempts from non-existent users';
