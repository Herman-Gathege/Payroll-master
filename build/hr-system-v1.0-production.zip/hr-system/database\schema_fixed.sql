-- HR Management System Database Schema - FIXED
-- Kenyan Compliance: SHIF, NSSF, KRA, Employment Act 2007

-- Drop existing tables if they exist (in reverse order of dependencies)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS positions;
SET FOREIGN_KEY_CHECKS = 1;

-- Departments (no dependencies)
CREATE TABLE departments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    head_id INT,
    parent_department_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Positions (depends on departments)
CREATE TABLE positions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    department_id INT,
    job_description TEXT,
    requirements TEXT,
    minimum_salary DECIMAL(12, 2),
    maximum_salary DECIMAL(12, 2),
    job_level ENUM('entry', 'junior', 'mid', 'senior', 'lead', 'manager', 'executive') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id)
);

-- Employees (depends on departments, positions)
CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_number VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    national_id VARCHAR(20) UNIQUE NOT NULL,
    kra_pin VARCHAR(20) UNIQUE NOT NULL,
    shif_number VARCHAR(50),
    nssf_number VARCHAR(50),
    date_of_birth DATE NOT NULL,
    gender ENUM('male', 'female', 'other') NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    personal_email VARCHAR(255),
    work_email VARCHAR(255),
    postal_address VARCHAR(255),
    residential_address TEXT,
    county VARCHAR(100),
    sub_county VARCHAR(100),
    marital_status ENUM('single', 'married', 'divorced', 'widowed'),
    nationality VARCHAR(100) DEFAULT 'Kenyan',
    passport_number VARCHAR(50),
    profile_photo VARCHAR(255),
    department_id INT,
    position_id INT,
    manager_id INT,
    employment_type ENUM('permanent', 'contract', 'intern', 'casual') NOT NULL,
    employment_status ENUM('active', 'on_leave', 'suspended', 'terminated', 'retired') DEFAULT 'active',
    hire_date DATE NOT NULL,
    probation_end_date DATE,
    contract_end_date DATE,
    termination_date DATE,
    termination_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (position_id) REFERENCES positions(id),
    FOREIGN KEY (manager_id) REFERENCES employees(id)
);

-- Users and Authentication (depends on employees - but employee_id is nullable)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'hr_manager', 'manager', 'employee') NOT NULL,
    employee_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL
);

-- Continue with rest of the schema...
-- I'll include only the essential tables for now to get you started quickly

-- Bank and Payment Details
CREATE TABLE employee_bank_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    payment_method ENUM('bank', 'mpesa', 'cash') NOT NULL,
    bank_name VARCHAR(100),
    branch_name VARCHAR(100),
    account_number VARCHAR(50),
    account_name VARCHAR(255),
    mpesa_number VARCHAR(20),
    is_primary BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Next of Kin
CREATE TABLE next_of_kin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    relationship VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    email VARCHAR(255),
    national_id VARCHAR(20),
    residential_address TEXT,
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Leave Types
CREATE TABLE leave_types (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    days_per_year INT NOT NULL,
    is_paid BOOLEAN DEFAULT TRUE,
    requires_medical_certificate BOOLEAN DEFAULT FALSE,
    max_consecutive_days INT,
    gender_specific ENUM('all', 'male', 'female') DEFAULT 'all',
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default leave types
INSERT INTO leave_types (name, code, days_per_year, is_paid, requires_medical_certificate, gender_specific, description) VALUES
('Annual Leave', 'ANNUAL', 21, TRUE, FALSE, 'all', 'Annual vacation leave as per Employment Act 2007'),
('Sick Leave', 'SICK', 14, TRUE, TRUE, 'all', 'Medical leave with certificate'),
('Maternity Leave', 'MATERNITY', 90, TRUE, FALSE, 'female', '3 months maternity leave for female employees'),
('Paternity Leave', 'PATERNITY', 14, TRUE, FALSE, 'male', '2 weeks paternity leave for male employees'),
('Compassionate Leave', 'COMPASSIONATE', 5, TRUE, FALSE, 'all', 'Leave due to death of immediate family member'),
('Study Leave', 'STUDY', 0, FALSE, FALSE, 'all', 'Leave for examinations or studies'),
('Unpaid Leave', 'UNPAID', 0, FALSE, FALSE, 'all', 'Leave without pay');

-- Leave Applications
CREATE TABLE leave_applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days_requested DECIMAL(5, 2) NOT NULL,
    reason TEXT NOT NULL,
    supporting_document VARCHAR(500),
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    applied_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    reviewed_by INT,
    review_date DATETIME,
    review_comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
);

-- Leave Balances
CREATE TABLE leave_balances (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    year INT NOT NULL,
    total_days DECIMAL(5, 2) NOT NULL,
    days_taken DECIMAL(5, 2) DEFAULT 0,
    days_pending DECIMAL(5, 2) DEFAULT 0,
    days_remaining DECIMAL(5, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_leave_year (employee_id, leave_type_id, year),
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id)
);

-- Attendance & Time Tracking
CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    clock_in DATETIME,
    clock_out DATETIME,
    clock_in_method ENUM('mobile', 'biometric', 'manual', 'web') DEFAULT 'manual',
    clock_out_method ENUM('mobile', 'biometric', 'manual', 'web') DEFAULT 'manual',
    clock_in_location VARCHAR(255),
    clock_out_location VARCHAR(255),
    clock_in_latitude DECIMAL(10, 8),
    clock_in_longitude DECIMAL(11, 8),
    clock_out_latitude DECIMAL(10, 8),
    clock_out_longitude DECIMAL(11, 8),
    work_hours DECIMAL(5, 2),
    overtime_hours DECIMAL(5, 2) DEFAULT 0,
    status ENUM('present', 'absent', 'late', 'half_day', 'on_leave', 'holiday') DEFAULT 'present',
    notes TEXT,
    approved_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_date (employee_id, attendance_date),
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- Salary Structures
CREATE TABLE salary_structures (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    basic_salary DECIMAL(12, 2) NOT NULL,
    housing_allowance DECIMAL(12, 2) DEFAULT 0,
    transport_allowance DECIMAL(12, 2) DEFAULT 0,
    medical_allowance DECIMAL(12, 2) DEFAULT 0,
    risk_allowance DECIMAL(12, 2) DEFAULT 0,
    other_allowances DECIMAL(12, 2) DEFAULT 0,
    gross_salary DECIMAL(12, 2) NOT NULL,
    effective_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);

-- Payroll
CREATE TABLE payroll (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    period_month INT NOT NULL,
    period_year INT NOT NULL,
    basic_salary DECIMAL(12, 2) NOT NULL,
    housing_allowance DECIMAL(12, 2) DEFAULT 0,
    transport_allowance DECIMAL(12, 2) DEFAULT 0,
    medical_allowance DECIMAL(12, 2) DEFAULT 0,
    overtime_pay DECIMAL(12, 2) DEFAULT 0,
    bonus DECIMAL(12, 2) DEFAULT 0,
    other_earnings DECIMAL(12, 2) DEFAULT 0,
    gross_pay DECIMAL(12, 2) NOT NULL,
    paye DECIMAL(12, 2) DEFAULT 0,
    shif_deduction DECIMAL(12, 2) DEFAULT 0,
    nssf_deduction DECIMAL(12, 2) DEFAULT 0,
    housing_levy DECIMAL(12, 2) DEFAULT 0,
    loans DECIMAL(12, 2) DEFAULT 0,
    advances DECIMAL(12, 2) DEFAULT 0,
    other_deductions DECIMAL(12, 2) DEFAULT 0,
    total_deductions DECIMAL(12, 2) NOT NULL,
    net_pay DECIMAL(12, 2) NOT NULL,
    status ENUM('draft', 'processed', 'approved', 'paid') DEFAULT 'draft',
    payment_date DATE,
    processed_by INT,
    approved_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_period (employee_id, period_month, period_year),
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (processed_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- System Settings
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type VARCHAR(50),
    description TEXT,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(id)
);

-- Default system settings
INSERT INTO system_settings (setting_key, setting_value, setting_type, description) VALUES
('company_name', 'Your Company Ltd', 'text', 'Company name'),
('company_kra_pin', '', 'text', 'Company KRA PIN'),
('company_nssf_number', '', 'text', 'Company NSSF number'),
('company_shif_number', '', 'text', 'Company SHIF number'),
('min_wage_kenya', '15000', 'number', 'Kenya minimum wage in KES'),
('work_hours_per_day', '8', 'number', 'Standard work hours per day'),
('work_days_per_week', '5', 'number', 'Standard work days per week'),
('overtime_rate', '1.5', 'number', 'Overtime pay multiplier');

-- Add foreign keys to departments that reference employees (after employees table exists)
ALTER TABLE departments ADD FOREIGN KEY (head_id) REFERENCES employees(id);

-- Success message
SELECT 'Database schema created successfully!' AS Status,
       'Core tables: users, employees, departments, positions' AS Core_Tables,
       'HR tables: leave, attendance, payroll, salary' AS HR_Tables,
       'Now run create_admin_user.sql to create admin account' AS Next_Step;
